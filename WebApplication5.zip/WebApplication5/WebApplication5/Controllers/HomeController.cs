﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Net.Http.Formatting;
using System.Collections.Generic;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        HttpClient client;
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetUsersData()
        {
            
            var users = GetTempSensorDetail();
            return Json(users, JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> homepage()
        {
               

            return Json(GetRoomData("1"), JsonRequestBehavior.AllowGet);
        }
       
        public async Task<JsonResult> GetACSensorDetail()
        {
            var type = "acstatus";
            HttpResponseMessage response = await GetClient(type).GetAsync(type);
            List<SensorData> sensorData = new List<SensorData>();
            if (response.IsSuccessStatusCode)
            {

                sensorData = await response.Content.ReadAsAsync<List<SensorData>>();
              
                sensorData = sensorData.OrderBy(x => x.id).Take(5)
                            .ToList();
            }


            return Json(sensorData, JsonRequestBehavior.AllowGet);

        }

        public async Task<JsonResult> GetLightSensorDetail()
        {
            var type = "lightstatus";
            HttpResponseMessage response = await GetClient(type).GetAsync(type);
            List<SensorData> sensorData = new List<SensorData>();
            if (response.IsSuccessStatusCode)
            {

                sensorData = await response.Content.ReadAsAsync<List<SensorData>>();
            

                sensorData = sensorData.OrderBy(x => x.id).Take(5)
                            .ToList();
            }


            return Json(sensorData, JsonRequestBehavior.AllowGet);

        }

        public async Task<JsonResult> GetMotionSensorDetail()
        {
            var type = "motionsensor";
            HttpResponseMessage response = await GetClient(type).GetAsync(type);
            List<SensorData> sensorData = new List<SensorData>();
            if (response.IsSuccessStatusCode)
            {

                sensorData = await response.Content.ReadAsAsync<List<SensorData>>();

                sensorData = sensorData.OrderByDescending(x => x.timestamp).Take(5)
            .ToList();

                sensorData = sensorData.OrderBy(x => x.id).Take(5)
                            .ToList();
            }
           

            return Json(sensorData, JsonRequestBehavior.AllowGet);

        }

        public async Task<JsonResult> GetDoorSensorDetail()
        {
            var type = "doorstatus";

            List<SensorData> sensorData = await GetSensorData(type);
            //HttpResponseMessage response = await GetClient(type).GetAsync(type);
            ////List<SensorData> sensorData = new List<SensorData>();
            //if (response.IsSuccessStatusCode)
            //{
               
            //   sensorData = await response.Content.ReadAsAsync<List<SensorData>>();


            //    sensorData = sensorData.OrderBy(x => x.id).Take(5)
            //                .ToList();
            //}


            return Json(sensorData, JsonRequestBehavior.AllowGet);

        }

        public async Task< List<SensorData>> GetSensorData(string type)
        {
            HttpResponseMessage response = await GetClient(type).GetAsync(type);
            List<SensorData> sensorData = new List<SensorData>();
            if (response.IsSuccessStatusCode)
            {

                sensorData =await  response.Content.ReadAsAsync<List<SensorData>>();


                sensorData = sensorData.OrderBy(x => x.id).Take(5)
                            .ToList();
            }
            return sensorData;
        }

        public async Task<JsonResult> GetTempSensorDetail()
        {
            var type = "tempsensor";
            HttpResponseMessage response = await GetClient(type).GetAsync(type);
            List<SensorData> sensorData = new List<SensorData>();
            if (response.IsSuccessStatusCode)
            {
                sensorData = await response.Content.ReadAsAsync<List<SensorData>>();
                sensorData = sensorData.OrderByDescending(x => x.timestamp).Take(5)
            .ToList();

                sensorData = sensorData.OrderBy(x => x.id).Take(5)
                            .ToList();
            }

            return Json(sensorData, JsonRequestBehavior.AllowGet);

        }

        public HttpClient GetClient(string type)
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://honmdu10june2017.mybluemix.net/3/" + type);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }
        public class ApplianceStatus
        {
            public string id { get; set; }
            public string value { get; set; }
        }

        public class SensorData
        {
            public string id { get; set; }
            public string value { get; set; }

            public string timestamp { get; set; }
        }

        [HttpPost]
        public void PostAction(string type, string idq, string valueq)
        {
            if (valueq == "0")
                valueq = "1";
            else
                valueq = "0";
                //   type = "lightstatus"; idq = "LIGHT_5"; valueq = "1";
                ApplianceStatus p = new ApplianceStatus { id = idq, value = valueq };

            //var type = "tempsensor";
            var response = GetClient(type).PutAsJsonAsync(type, p).Result;
            if (response.IsSuccessStatusCode)
            {
              //  return new JsonResult({"success","true" });
            }

           // return new JsonResult();
        }

        public async Task<JsonResult> GetRoomData(string no)
        {
            List<SensorData> roomdata = await GetSensorData("acstatus");
            roomdata.AddRange(await GetSensorData("doorstatus"));
            roomdata.AddRange(await GetSensorData("lightstatus"));
            roomdata.AddRange(await GetSensorData("motionsensor"));
            roomdata.AddRange(await GetSensorData("tempsensor"));
            // return Json(roomdata, JsonRequestBehavior.AllowGet);
            return Json(roomdata.Where(x => x.id.Contains(no)), JsonRequestBehavior.AllowGet);
        }

     
    }
}